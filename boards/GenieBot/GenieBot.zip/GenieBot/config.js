module.exports = {
  name: "GenieBot",
  platform: "arduino-pico",
  title: "GenieBot",
  description: "ชุดหุ่นยนต์ อปท. ประถม",
  author: "PrinceBot",
  website: "https://PrinceBotShop.com",
  email: "print081@gmail.com",
  git: "https://github.com/PrinceBot-Ratthanin/GenieBot",
  download_url:
    "https://woottinan.github.io/kbide-board-repo/boards/GenieBot/GenieBot.zip",
  image: "/static/robot.png",
  version: "2.8.0",
};
