module.exports = {
  name: "RapbitPro",
  platform: "arduino-esp32",
  title: "RapbitPro",
  description: "หุ่นยนต์แห่งการเรียนรู้",
  author: "Ratthanin Kittisriphong",
  website: "https://PrinceBot.net",
  email: "print081@gmail.com",
  git: "https://github.com/PrinceBot-Ratthanin/RapbitPro/",
  download_url: "https://woottinan.github.io/kbide-board-repo/boards/RapbitPro/RapbitPro.zip",
  image: "/static/RapbitPro.png",
  version: "1.0.0",
};
