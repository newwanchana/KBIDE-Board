module.exports = {
  name: "GenieBotV2",
  platform: "arduino-pico",
  title: "GenieBotV2",
  description: "ชุดหุ่นยนต์ อปท. ประถม",
  author: "PrinceBot",
  website: "https://PrinceBotShop.com",
  email: "print081@gmail.com",
  git: "https://github.com/PrinceBot-Ratthanin/GenieBotV2",
  download_url:
    "https://woottinan.github.io/kbide-board-repo/boards/GenieBotV2/GenieBotV2.zip",
  image: "/static/robot.png",
  version: "1.3.0",
};
