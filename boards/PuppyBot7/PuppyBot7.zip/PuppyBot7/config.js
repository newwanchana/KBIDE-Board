module.exports = {
  name: "puppybot7",
  platform: "arduino-rp2350",
  title: "puppybot7",
  description: "บอร์ดควบคุมหุ่นยนต์พลัง rp2350B",
  author: "PrinceBot",
  website: "https://princebot.net",
  email: "print081@gmail.com",
  git: "https://github.com/newwanchana/KBIDE-Board/tree/main/boards/PuppyBot7",
  download_url:
    "https://newwanchana.github.io/KBIDE-Board/boards/PuppyBot6/PuppyBot7.zip",
  image: "/static/cover.jpg",
  version: "3.0.0",
  fqbn: "rp2040:rp2040:puppybot7",
  corePath: "arduino-rp2350",
};
