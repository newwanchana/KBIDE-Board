const dirIcon = Vue.prototype.$global.board.board_info.dir;
module.exports = function(Blockly){
  'use strict';

Blockly.Blocks['sw1_press'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("SW1_press");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(65);
 this.setTooltip("Buzzer beep");
 this.setHelpUrl("");
  }
};
Blockly.Blocks['button_1_status'] = {
  init: function() {
    this.appendDummyInput()
        .appendField(new Blockly.FieldImage("/static/icons/sw12x12.png", 20, 20, "*"))
        .appendField("SW1 is pressed");
    this.setInputsInline(true);
    this.setOutput(true, "Number");
    this.setColour(65);
 this.setTooltip("get SW1 pressed or not");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['Ultrasinoc_sensor'] = {
  init: function() {
    this.appendDummyInput()
        //.appendField(new Blockly.FieldImage("/static/icons/bmx055.png", 20, 20, "*"))
        .appendField("Read Distance");
    this.setInputsInline(true);
    this.setOutput(true, "Number");
    this.setColour(65);
 this.setTooltip("Read Distance");
 this.setHelpUrl("");
  }
};
Blockly.Blocks['Light_Sensor'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Light sensor(ADC):")
        .appendField(new Blockly.FieldDropdown([["0","0"],["1","1"], ["2","2"], ["3","3"],
        										["4","4"],["5","5"], ["6","6"], ["7","7"], ["8","8"], ["9","9"], ["10","12"]]), "pin");
    this.setOutput(true);
    this.setColour(65);
    this.setTooltip("read pos EncoderA Pin 26");
    this.setHelpUrl("");
  }
};
Blockly.Blocks['Irremote_sensor'] = {
  init: function() {
    this.appendDummyInput()
        //.appendField(new Blockly.FieldImage("/static/icons/bmx055.png", 20, 20, "*"))
        .appendField("Read Remote");
    this.setInputsInline(true);
    this.setOutput(true, "Number");
    this.setColour(65);
 this.setTooltip("Read Distance");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['Puppy_beep'] = {
  init: function() {
    this.appendDummyInput()
        .appendField("Buzzer beep");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(65);
 this.setTooltip("Buzzer beep");
 this.setHelpUrl("");
  }
};
var PIN_OPTIONS = [
  ['P0','0'], ['P1','1'], ['P2','2'], ['P3','3'],
  ['P4','4'], ['P5','5'], ['P6','6'], ['P7','7'],
  ['P8','8'], ['P9','9'], ['P10','10'], ['P11','11'],
  ['P12','12'], ['P13','13'], ['P14','14'], ['P15','15']
];

Blockly.Blocks['Set_pin_for_PID'] = {
  init: function() {
    this.itemCount_ = 2;
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(330);
    this.updateShape_();
  },

  // === mutation ===
  mutationToDom: function() {
    var container = document.createElement('mutation');
    container.setAttribute('items', this.itemCount_);
    return container;
  },

  domToMutation: function(xmlElement) {
    var n = parseInt(xmlElement.getAttribute('items'), 10);
    this.itemCount_ = isNaN(n) ? 0 : Math.max(0, n);
    this.updateShape_();
  },

  // === เก็บ/คืนค่า connections (กัน null เสมอ) ===
  storeConnections_: function() {
    this.valueConnections_ = [];
    for (var i = 0; i < this.itemCount_; i++) {
      var input = this.getInput('ADD' + i);
      var target = (input && input.connection) ? input.connection.targetConnection : null;
      this.valueConnections_.push(target);
    }
  },

  restoreConnections_: function() {
    for (var i = 0; i < this.itemCount_; i++) {
      if (this.valueConnections_[i]) {
        Blockly.Mutator.reconnect(this.valueConnections_[i], this, 'ADD' + i);
      }
    }
  },

  // === เพิ่ม/ลบรายการ ===
  addItem_: function() {
    this.storeConnections_();
    var update = function() { this.itemCount_++; };
    this.update_(update);
    this.restoreConnections_();

    // (ออปชัน) โคลน shadow จากช่องแรกไปช่องใหม่ ถ้ามีจริง
    if (this.itemCount_ > 1) {
      var firstInput = this.getInput('ADD0');
      var newInput = this.getInput('ADD' + (this.itemCount_ - 1));
      if (firstInput && firstInput.connection && newInput && newInput.connection) {
        var shadowInputDom = firstInput.connection.getShadowDom && firstInput.connection.getShadowDom();
        if (shadowInputDom) {
          var shadowDom = shadowInputDom.cloneNode(true);
          // ใส่ id ใหม่กันซ้ำ
          if (Blockly.utils && Blockly.utils.genUid) {
            shadowDom.setAttribute('id', Blockly.utils.genUid());
          }
          newInput.connection.setShadowDom(shadowDom);
          if (newInput.connection.respawnShadow_) newInput.connection.respawnShadow_();
        }
      }
    }
  },

  removeItem_: function() {
    if (this.itemCount_ <= 0) return;
    this.storeConnections_();
    var update = function() { this.itemCount_--; };
    this.update_(update);
    this.restoreConnections_();
  },

  // === ตัวห่อ update + อีเวนต์/เรนเดอร์ ===
  update_: function(update) {
    Blockly.Events.setGroup(true);
    var block = this;

    var oldMutationDom = block.mutationToDom();
    var oldMutation = oldMutationDom && Blockly.Xml.domToText(oldMutationDom);

    var savedRendered = block.rendered;
    block.rendered = false;

    if (typeof update === 'function') update.call(this);
    this.updateShape_();

    block.rendered = savedRendered;
    block.initSvg();

    var group = Blockly.Events.getGroup();
    var newMutationDom = block.mutationToDom();
    var newMutation = newMutationDom && Blockly.Xml.domToText(newMutationDom);

    if (oldMutation !== newMutation) {
      Blockly.Events.fire(new Blockly.Events.BlockChange(
        block, 'mutation', null, oldMutation, newMutation
      ));
      setTimeout(function() {
        Blockly.Events.setGroup(group);
        if (typeof block.bumpNeighbours_ === 'function') block.bumpNeighbours_();
        Blockly.Events.setGroup(false);
      }, Blockly.BUMP_DELAY);
    }

    if (block.rendered) block.render();
    Blockly.Events.setGroup(false);
  },

  // === รูปทรงบล็อกหลัก ===
  updateShape_: function() {
    var that = this;
    var add = function() { that.addItem_(); };
    var remove = function() { that.removeItem_(); };

    // หัวเรื่อง/ว่าง
    if (this.itemCount_) {
      if (this.getInput('EMPTY')) this.removeInput('EMPTY');
      if (!this.getInput('TITLE')) {
        this.appendDummyInput('TITLE').appendField('Set pin');
      }
    } else {
      if (this.getInput('TITLE')) this.removeInput('TITLE');
      if (!this.getInput('EMPTY')) {
        this.appendDummyInput('EMPTY').appendField('Create empty');
      }
    }

    // สร้าง/อัปเดตอินพุต
    var i = 0;
    for (i = 0; i < this.itemCount_; i++) {
      var name = 'ADD' + i;
      if (!this.getInput(name)) {
        // ใช้ ValueInput เพื่อมี connection + ใส่ dropdown PIN ไว้หน้า
        var inp = this.appendDummyInput(name).appendField('S' + i);
        inp.appendField(new Blockly.FieldDropdown(PIN_OPTIONS), 'PIN' + i);
      } else {
        // ถ้ามีแล้ว ให้แน่ใจว่ามี dropdown PIN เสมอ
        var inp2 = this.getInput(name);
        if (!this.getField('PIN' + i)) {
          inp2.insertFieldAt(0, new Blockly.FieldDropdown(PIN_OPTIONS), 'PIN' + i);
        }
      }
    }

    // ลบอินพุตส่วนเกิน
    while (this.getInput('ADD' + i)) {
      this.removeInput('ADD' + i);
      i++;
    }

    // ปุ่ม +/-
    if (this.getInput('BUTTONS')) this.removeInput('BUTTONS');
    var buttons = this.appendDummyInput('BUTTONS');
    if (this.itemCount_ > 0) {
      buttons.appendField(new Blockly.FieldImage(
        '/static/icons/minus.png', 20, 20, '*', remove, true
      ));
    }
    buttons.appendField(new Blockly.FieldImage(
      '/static/icons/plus.png', 20, 20, '*', add, true
    ));

    // inline เมื่อจำนวนน้อย
    this.setInputsInline(this.itemCount_ <= 10);
  }
};
Blockly.Blocks["Set_Min_for_PID"] = {
  init: function(){    
    this.itemCount_ = 2;
    this.updateShape_();
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    //this.setMutator(new Blockly.Mutator(['lists_create_with_item']));
    this.setColour(330);
  },
  mutationToDom: function() {
    var container = document.createElement('mutation');
    container.setAttribute('items', this.itemCount_);
    return container;
  },
  domToMutation: function(xmlElement) {
    this.itemCount_ = parseInt(xmlElement.getAttribute('items'), 10);
    this.updateShape_();
  },
  storeConnections_: function() {
    this.valueConnections_ = [];
    for (var i = 0; i < this.itemCount_; i++) {
      this.valueConnections_.push(this.getInput('ADD' + i).connection.targetConnection);
    }
  },
  restoreConnections_: function() {
    for (var i = 0; i < this.itemCount_; i++) {
      Blockly.Mutator.reconnect(this.valueConnections_[i], this, 'ADD' + i);
    }
  },
  addItem_: function() {
    this.storeConnections_();
    var update = function() {
      this.itemCount_++;
    };
    this.update_(update);
    this.restoreConnections_();
    // Add shadow block
    if (this.itemCount_ > 1) {
      // Find shadow type
      var firstInput = this.getInput('ADD' + 0);
      if (firstInput && firstInput.connection.targetConnection) {
        var newInput = this.getInput('ADD' + (this.itemCount_ - 1));
        var shadowInputDom = firstInput.connection.getShadowDom();
        if (shadowInputDom) {
          var shadowDom = document.createElement('shadow');
          var shadowInputType = shadowInputDom.getAttribute('type');
          shadowDom.setAttribute('type', shadowInputType);
          var shadowDomField = document.createElement('field');
          shadowDomField.setAttribute('name', 'NUM');
          shadowDom.appendChild(shadowDomField);
          if (shadowDom) {
            shadowDom.setAttribute('id', Blockly.utils.genUid());
            newInput.connection.setShadowDom(shadowDom);
            newInput.connection.respawnShadow_();
          }
        }
      }
    }
  },
  removeItem_: function() {
    this.storeConnections_();
    var update = function() {
      this.itemCount_--;
    };
    this.update_(update);
    this.restoreConnections_();
  },
  update_: function(update) {
    Blockly.Events.setGroup(true);
    var block = this;
    var oldMutationDom = block.mutationToDom();
    var oldMutation = oldMutationDom && Blockly.Xml.domToText(oldMutationDom);
    var savedRendered = block.rendered;
    block.rendered = false;
    if (update) update.call(this);
    this.updateShape_();
    block.rendered = savedRendered;
    block.initSvg();
    var group = Blockly.Events.getGroup();
    var newMutationDom = block.mutationToDom();
    var newMutation = newMutationDom && Blockly.Xml.domToText(newMutationDom);
    if (oldMutation != newMutation) {
      Blockly.Events.fire(new Blockly.Events.BlockChange(
          block, 'mutation', null, oldMutation, newMutation));
      setTimeout(function() {
        Blockly.Events.setGroup(group);
        block.bumpNeighbours_();
        Blockly.Events.setGroup(false);
      }, Blockly.BUMP_DELAY);
    }
    if (block.rendered) {
      block.render();
    }
    Blockly.Events.setGroup(false);
  },
  /**
   * Modify this block to have the correct number of inputs.
   * @private
   * @this Blockly.Block
   */
  updateShape_: function() {
    var that = this;
    var add = function() {
      that.addItem_();
    };
    var remove = function() {
      that.removeItem_();
    };
    if (this.itemCount_) {
      if (this.getInput('EMPTY')) this.removeInput('EMPTY');
      if (!this.getInput('TITLE')) {
        this.appendDummyInput('TITLE')
            .appendField("Set Min");
      }
    } else {
      if (this.getInput('TITLE')) this.removeInput('TITLE');
      if (!this.getInput('EMPTY')) {
        this.appendDummyInput('EMPTY')
            .appendField("Create empty");
      }
    }
    var i = 0;
    // Add new inputs.
    for (i = 0; i < this.itemCount_; i++) {
      if (!this.getInput('ADD' + i)) {
        this.appendValueInput('ADD' + i)
        .appendField('S' + i);
      }
    }
    // Remove deleted inputs.
    while (this.getInput('ADD' + i)) {
      this.removeInput('ADD' + i);
      i++;
    }
    if (this.getInput('BUTTONS')) this.removeInput('BUTTONS');
    var buttons = this.appendDummyInput('BUTTONS');
    if (this.itemCount_ > 0) {      
      buttons.appendField(new Blockly.FieldImage("/static/icons/minus.png", 20, 20, "*",remove,true));
    }
    buttons.appendField(new Blockly.FieldImage("/static/icons/plus.png", 20, 20, "*", add,true));
    var showHorizontalList = this.itemCount_ <= 10;
    this.setInputsInline(showHorizontalList);    
  }
}
Blockly.Blocks["Set_Max_for_PID"] = {
  init: function(){    
    this.itemCount_ = 2;
    this.updateShape_();
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    //this.setMutator(new Blockly.Mutator(['lists_create_with_item']));
    this.setColour(330);
  },
  mutationToDom: function() {
    var container = document.createElement('mutation');
    container.setAttribute('items', this.itemCount_);
    return container;
  },
  domToMutation: function(xmlElement) {
    this.itemCount_ = parseInt(xmlElement.getAttribute('items'), 10);
    this.updateShape_();
  },
  storeConnections_: function() {
    this.valueConnections_ = [];
    for (var i = 0; i < this.itemCount_; i++) {
      this.valueConnections_.push(this.getInput('ADD' + i).connection.targetConnection);
    }
  },
  restoreConnections_: function() {
    for (var i = 0; i < this.itemCount_; i++) {
      Blockly.Mutator.reconnect(this.valueConnections_[i], this, 'ADD' + i);
    }
  },
  addItem_: function() {
    this.storeConnections_();
    var update = function() {
      this.itemCount_++;
    };
    this.update_(update);
    this.restoreConnections_();
    // Add shadow block
    if (this.itemCount_ > 1) {
      // Find shadow type
      var firstInput = this.getInput('ADD' + 0);
      if (firstInput && firstInput.connection.targetConnection) {
        var newInput = this.getInput('ADD' + (this.itemCount_ - 1));
        var shadowInputDom = firstInput.connection.getShadowDom();
        if (shadowInputDom) {
          var shadowDom = document.createElement('shadow');
          var shadowInputType = shadowInputDom.getAttribute('type');
          shadowDom.setAttribute('type', shadowInputType);
          var shadowDomField = document.createElement('field');
          shadowDomField.setAttribute('name', 'NUM');
          shadowDom.appendChild(shadowDomField);
          if (shadowDom) {
            shadowDom.setAttribute('id', Blockly.utils.genUid());
            newInput.connection.setShadowDom(shadowDom);
            newInput.connection.respawnShadow_();
          }
        }
      }
    }
  },
  removeItem_: function() {
    this.storeConnections_();
    var update = function() {
      this.itemCount_--;
    };
    this.update_(update);
    this.restoreConnections_();
  },
  update_: function(update) {
    Blockly.Events.setGroup(true);
    var block = this;
    var oldMutationDom = block.mutationToDom();
    var oldMutation = oldMutationDom && Blockly.Xml.domToText(oldMutationDom);
    var savedRendered = block.rendered;
    block.rendered = false;
    if (update) update.call(this);
    this.updateShape_();
    block.rendered = savedRendered;
    block.initSvg();
    var group = Blockly.Events.getGroup();
    var newMutationDom = block.mutationToDom();
    var newMutation = newMutationDom && Blockly.Xml.domToText(newMutationDom);
    if (oldMutation != newMutation) {
      Blockly.Events.fire(new Blockly.Events.BlockChange(
          block, 'mutation', null, oldMutation, newMutation));
      setTimeout(function() {
        Blockly.Events.setGroup(group);
        block.bumpNeighbours_();
        Blockly.Events.setGroup(false);
      }, Blockly.BUMP_DELAY);
    }
    if (block.rendered) {
      block.render();
    }
    Blockly.Events.setGroup(false);
  },
  /**
   * Modify this block to have the correct number of inputs.
   * @private
   * @this Blockly.Block
   */
  updateShape_: function() {
    var that = this;
    var add = function() {
      that.addItem_();
    };
    var remove = function() {
      that.removeItem_();
    };
    if (this.itemCount_) {
      if (this.getInput('EMPTY')) this.removeInput('EMPTY');
      if (!this.getInput('TITLE')) {
        this.appendDummyInput('TITLE')
            .appendField("Set Max");
      }
    } else {
      if (this.getInput('TITLE')) this.removeInput('TITLE');
      if (!this.getInput('EMPTY')) {
        this.appendDummyInput('EMPTY')
            .appendField("Create empty");
      }
    }
    var i = 0;
    // Add new inputs.
    for (i = 0; i < this.itemCount_; i++) {
      if (!this.getInput('ADD' + i)) {
        this.appendValueInput('ADD' + i)
        .appendField('S' + i);
      }
    }
    // Remove deleted inputs.
    while (this.getInput('ADD' + i)) {
      this.removeInput('ADD' + i);
      i++;
    }
    if (this.getInput('BUTTONS')) this.removeInput('BUTTONS');
    var buttons = this.appendDummyInput('BUTTONS');
    if (this.itemCount_ > 0) {      
      buttons.appendField(new Blockly.FieldImage("/static/icons/minus.png", 20, 20, "*",remove,true));
    }
    buttons.appendField(new Blockly.FieldImage("/static/icons/plus.png", 20, 20, "*", add,true));
    var showHorizontalList = this.itemCount_ <= 10;
    this.setInputsInline(showHorizontalList);    
  }
}
Blockly.Blocks['Set_Mode_Sensor'] = {
  init: function() {
    
    this.appendDummyInput()
        .appendField("Set_Mode_Sensor")
        .appendField(new Blockly.FieldDropdown([["8Ch","0"],["16Ch","1"]]), "Mode");
    this.setPreviousStatement(true, null);
    this.setNextStatement(true, null);
    this.setColour(330);
 this.setTooltip("Set Mode Sensor");
 this.setHelpUrl("");
  }
};

Blockly.Blocks['Read_ADC_ALL'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("Read Analog from sensor");
      this.appendDummyInput()
        .appendField(new Blockly.FieldDropdown([["8Ch","0"],["16Ch","1"]]), "Mode");
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(65);
   this.setTooltip("Read Analog from sensor");
   this.setHelpUrl("");
    }
  };

}