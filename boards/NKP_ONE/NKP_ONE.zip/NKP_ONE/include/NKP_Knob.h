#define _knob 36
int Knob(){
  return analogRead(_knob);
}
