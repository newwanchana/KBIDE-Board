# template package

## Project setup
```
npm install
```

### Run for development
```
npm run serve
```

### Compile as library
```
npm run build
```
