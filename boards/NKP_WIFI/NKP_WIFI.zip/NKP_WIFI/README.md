# NKP_WIFI  IoT board for KBIDE
