module.exports = function(Blockly){
  'use strict';
Blockly.JavaScript['sw1_press'] = function(block) {  
  var code = 'wait_SW1();\n';
  return code;
};
Blockly.JavaScript['button_1_status'] = function(block) {  
  var code = '(digitalRead(12))';  
  return [code, Blockly.JavaScript.ORDER_ATOMIC];
};


Blockly.JavaScript['Set_Min_for_PID'] = function(block) {
  var args = [];
  for (var i = 0; ; i++) {
    var inputName = 'ADD' + i;
    if (!block.getInput(inputName)) break;
    var argCode = Blockly.JavaScript.valueToCode(block, inputName, Blockly.JavaScript.ORDER_NONE) || '0';
    args.push(argCode);
  }

  // เปลี่ยนชื่อฟังก์ชันได้ตามต้องการ
  var code = 'setSensorMin((const int[]){' + args.join(', ') + '});\n';
  return code; // เป็น statement block
};

Blockly.JavaScript['Set_Max_for_PID'] = function(block) {
  var args = [];
  for (var i = 0; ; i++) {
    var inputName = 'ADD' + i;
    if (!block.getInput(inputName)) break;
    var argCode = Blockly.JavaScript.valueToCode(block, inputName, Blockly.JavaScript.ORDER_NONE) || '0';
    args.push(argCode);
  }

  // เปลี่ยนชื่อฟังก์ชันได้ตามต้องการ
  var code = 'setSensorMax((const int[]){' + args.join(', ') + '});\n';
  return code; // เป็น statement block
};

// Blockly.JavaScript['Set_pin_for_PID'] = function(block) {
//   var args = [];
//   for (var i = 0; ; i++) {
//     var inputName = 'ADD' + i;
//     if (!block.getInput(inputName)) break;
//     var argCode = Blockly.JavaScript.valueToCode(block, inputName, Blockly.JavaScript.ORDER_NONE) || '0';
//     args.push(argCode);
//   }

//   // เปลี่ยนชื่อฟังก์ชันได้ตามต้องการ
//   var code = 'setSensorPins((const int[]){' + args.join(', ') + '};\n';
//   return code; // เป็น statement block
// };

Blockly.JavaScript['Set_pin_for_PID'] = function(block) {
  var pins = [];
  for (var i = 0; ; i++) {
    var inputName = 'ADD' + i;
    if (!block.getInput(inputName)) break;

    // อ่านค่าพินจาก dropdown
    var pinVal = block.getFieldValue('PIN' + i) || '0';
    pins.push(pinVal);
  }

  // แปลงเป็น C-style array literal + ส่งจำนวนสมาชิก
  var code = 'setSensorPins((const int[]){' + pins.join(', ') + '}, ' + pins.length + ');\n';
  return code;
};
Blockly.JavaScript['Set_Mode_Sensor'] = function(block) {  
	var value_Mode = block.getFieldValue('Mode'); 
  var code = 'Set_Mode_Sensor('+value_Mode+');\n';
  return code;
};

  Blockly.JavaScript['Read_ADC_ALL'] = function(block) { 
  var value_Mode = block.getFieldValue('Mode'); 
  var code = 'ReadADCAll('+value_Mode+');\n';
  return code;
};

}